const express = require('express')
const router = express.Router()
const Course = require('../models/Course')

router.get('/',async (req,res)=>{
    try {
        const results = await Course.find()
        if (results) {
            res.status(200).json(results)
        }else{
            res.status(404).json("Sorry,No Data Found!")
        }
    } catch (error){
        console.error(error);
        res.status(500).send("Server error!")
    }
})

router.get('/:id', async (req, res) => {
    try {
        const course = await Course.findById(req.params.id);
        if (course) {
            res.status(200).json(course);
        } else {
            res.status(404).json({ message: "Course not found!" });
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Server error!" });
    }
});

module.exports = router